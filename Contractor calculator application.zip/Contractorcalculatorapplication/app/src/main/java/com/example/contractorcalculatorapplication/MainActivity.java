package com.example.contractorcalculatorapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    private TextView textView, textView2, textView3;
    private EditText editText, editText2, editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.etLabor);
        editText2 = findViewById(R.id.etMaterialcost);
        editText3 = findViewById(R.id.etTaxRatePercent);
        Button calculate = findViewById(R.id.btnCalculate);
        Button changeRate = findViewById(R.id.btnChangeRate);
        textView = findViewById(R.id.tvSubtotalAmt);
        textView2 = findViewById(R.id.tvTaxTotalAmt);
        textView3 = findViewById(R.id.tvTotalAmt);
        calculate.setOnClickListener(view -> {
            double lCost = Double.parseDouble(editText.getText().toString());
            double mCost = Double.parseDouble(editText2.getText().toString());
            double sub = Double.parseDouble(String.format("%.2f",lCost + mCost));
            textView.setText(String.valueOf(sub));

            double taxRt = Double.parseDouble(editText3.getText().toString());
            double tax = Double.parseDouble(String.format("%.2f",sub * taxRt));
            textView2.setText(String.valueOf(tax));

            double total = Double.parseDouble(String.format("%.2f",sub + tax));
            textView3.setText(String.valueOf(total));
            System.out.println("Sub: " +sub);
            System.out.println("total: "+total);
            System.out.println("tax: "+tax);
            System.out.println("tax rt: "+taxRt);
            System.out.println("lcost: "+lCost);
            System.out.println("mcost: "+ mCost);
        });
        changeRate.setOnClickListener(view -> {
            editText3.setText("");
            textView2.setText("");
            textView3.setText("");
        });
    }
}